

ind_choices <- c("Balanza Comercial" = "1",
                 "Establecimientos Comerciales" = "2",
                 "Indicador Global de Actividad Económica (Original)" = "3",
                 "Indicador Global de Actividad Económica (Desestacionalizado)" = "4",
                 "Índice Mensual de Actividad Industrial (Original)"= "5",
                 "Índice Mensual de Actividad Industrial (Desestacionalizado)"= "6",
                 "Indicador Mensual de Consumo Privado en el Mercado Interior (Original)" = "7",
                 "Indicador Mensual de Consumo Privado en el Mercado Interior (Desestacionalizado)" = "8",
                 "Indicador de Confianza del Consumidor" = "9",
                 "Índice Nacional de Precios al Consumidor (Mensual)" = "10",
                 "Índice Nacional de Precios al Consumidor (Quincenal)" = "11",
                 "Inflación (Mensual)" = "12",
                 "Inflación (Mensual, Interanual)" = "13",
                 "Inflación (Anual acumulada)" = "14",
                 "Inflación (Quincenal)" = "15",
                 "Inversión Fija Bruta (Original)" = "16",
                 "Inversión Fija Bruta (Desestacionalizada)" = "17",
                 "Producto Interno Bruto (a precios de 2013)" = "18",
                 "Reservas Internacionales (Mensual)" = "19",
                 "Reservas Internacionales (Semanal)"= "20",
                 "Remesas" = "21",
                 "Sistema de Indicadores Compuestos" = "22",
                 "Tasa de Desocupación" = "23",
                 "Valor de la construcción" = "24",
                 "Vehículos Automotores" = "25",
                 #fin choices mex
                 "Business Sales and Inventories" = "26",
                  "University of Michigan: Surveys of Consumers" = "27",
                  "Construction Spending" = "28",
                 "Consumer Credit" = "29",
                 "Annual GDP - Index (2012=100)" = "30",
                 "Annual GDP - Seasonally Adjusted" = "31",
                 "Consumer Price Index - 1982-1984=100" = "32",
                 "Producer Price Index - Index Dec 1984=100"= "33"
                  )



#definimos ui
ui <-fluidPage(
  #tags$h2("My secure application"),
  #verbatimTextOutput("auth_output"),
  useShinyjs(),
  theme = shinytheme("cerulean"),
  titlePanel(title ="AsApAnalytics"),
  #grid de logotipo de asapa en background
  #setBackgroundImage(src= "asapa_back.png"),
  
  navbarPage("InfoAsApA",
             tabPanel("Indicadores Económicos",
                      #layout de sidebars
                      #sidebar para inputs
                      sidebarPanel(
            
                        
                        #input: seleccionar indicador
                        selectizeInput("dataset", "Seleccione el indicador deseado",
                                    choices = ind_choices, selected = "1", multiple = TRUE,
                                    options = list(maxItems = 5)
                                    
                        ),
                        
                        #sidebars condicionales dependiendo de qué tabset selecciones
                        conditionalPanel(condition="input.tabselected==1",
                                         #input: seleccionar serie vs varmensual vs varanual                 
                                         radioButtons("sertype", "Tipo de serie a mostrar:",
                                                      c("Principal" = "princ", "Variación Periodo a Periodo" = "varmensual", "Variación a 12 periodos"= "varanual")),
                                         #input: seleccionar series para gráficas principales (dinámicas)
                                         uiOutput("selectseries"),
                        ),#fin del tabset condicional para la serie principal
                        
                        conditionalPanel(condition="input.tabselected==2",
                                         #input: seleccionar serie para pronóstico
                                         uiOutput("selectforecast"),
                                         selectInput("fcperiod", "Seleccione el número de periodos a pronósticar",
                                                     choices =c("6","12","24"))
                        ), #fin del tabset condicional para pronóstico
                        conditionalPanel(condition="input.tabselected==3",
                                         uiOutput("seriescorr1"),
                                         uiOutput("seriescorr2")
                        ),
                        # Input: seleccionar datos a descargar
                        # botón de descarga de los datos
                        downloadButton("downloadData", "Descargar Datos"),
                        actionButton("updateData", "Actualizar Bases de Datos"),
                      ),
                      
                      #panel principal para mostrar outputs
                      mainPanel(
                        #output: tabset
                        #22-10-21 cambio de output de dygraph a plotly para TSstudio, comment las estáticas por obsoletas
                        tabsetPanel(type = "tabs",
                                    tabPanel("Gráfica principal", value=1,
                                             plotlyOutput("plotly1", height=500),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             textOutput("series_descrip"),
                                             br(),
                                             dataTableOutput("tabla")
                                    ),
                                    tabPanel("Pronóstico y Análisis", value = 2,
                                             br(),
                                             textOutput("forecast_descrip"),
                                             br(),
                                             plotlyOutput("dy_arima"),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             br(),
                                             plotlyOutput("tsdecomp"),
                                             br(),
                                             plotlyOutput("tslag"),
                                             #verbatimTextOutput("arimafc"),
                                             #dygraphOutput("dy_arfima"),
                                             #plotOutput("arfimaplot"),
                                             br()
                                             #verbatimTextOutput("arfimafc")
                                    ),
                                    tabPanel("Análisis Comparativo de Correlación", value = 3,
                                             plotlyOutput("scatterplot", height=500),
                                             br(),
                                             plotOutput("corr", height = 900)
                                    ),
                                    id = "tabselected" #para cambiar el sidebar dependiendo del tab
                        )
                      )
                      
                      
             ), #fin tabpanel
             tabPanel("Suba su propio csv",
                      sidebarPanel(
                        #Selector for file upload
                        fileInput('target_upload', 'Seleccione archivo para subir',
                                  accept = c(
                                    'text/csv',
                                    'text/comma-separated-values',
                                    '.csv'
                                  )),
                        radioButtons("separator","Separador: ",choices = c(";",",",":"), selected=";",inline=TRUE),
                        uiOutput("selectseries2")
                      ),

                      #panel para outputs
                      mainPanel(
                        tabsetPanel(type = "tabs",
                                    tabPanel("Tabla con los datos subidos",
                                             DT::dataTableOutput("sample_table")
                                             
                                    ),#fin tabpanel ver tabla
                                    tabPanel("Visualización de los datos",
                                      plotlyOutput("usergraph")
                                    )
                        )
                      )
             )#fin tabpanel csv

  )#fin navbars
)

# Wrap your UI with secure_app
ui <- secure_app(ui)

